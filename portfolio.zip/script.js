// jQuery(document).on('scroll', function () {
//     scrollValue = Math.round(scrollY);

//     if(scrollValue > 350){
//         console.log(scrollValue);
//         jQuery('#move').css("left", Math.max(100 - 0.2 * window.scrollY, 1) + "vw");
//     }
// })